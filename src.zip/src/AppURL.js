 const APP_URL = {
    BaseURL: "http://164.52.219.97",
    vendorSearch : "/grochouse/api/Homepage/SearchByVendorShortName",
   
}

export default APP_URL;